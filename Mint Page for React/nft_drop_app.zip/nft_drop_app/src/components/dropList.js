import contract from "../contract/contract.json";
import Web3 from "web3";
import { useState, useEffect } from "react";


const initialInfo = {
    connected: false,
    status: null,
    account: null,
    contract: null,
    address: null
};

const initWorkflowState = {
    loading: false,
    value: null,
    price: null,
    mintNFT: null,
    totalNFT: null


};



const DropList = () => {
    const [info, setInfo] = useState(initialInfo);
    const [workflow, setWorkflow] = useState(initWorkflowState);


    const init = async () => {
        if (window.ethereum.isMetaMask) {
            console.log("you have metamask", window.ethereum)
            const accounts = await window.ethereum.request({
                method: "eth_requestAccounts",
            });
            const networkId = await window.ethereum.request({
                method: "net_version",
            });


            /// a ajouter pour les ethereum mainnet
            if (networkId == 4) {
                let web3 = new Web3(window.ethereum);
                setInfo({
                    ...initialInfo,
                    status: "connected to metamask",
                    account: accounts[0],
                    contract: new web3.eth.Contract(contract.abi, contract.adress),

                });



            } else {
                setInfo({
                    ...initialInfo, status: "You need to be on the ethereum Testnet"
                });
            }
        } else {
            console.log("you need metamask")
            setInfo({ ...initialInfo, status: "You need Metamask" })
        }
    };

    //relancer la page en cas de changement de wallet ou de chaine
    const initOnChange = () => {
        if (window.ethereum) {
            window.ethereum.on("accountsChanged", () => {
                window.location.reload();
            });
            window.ethereum.on("chainChanged", () => {
                window.location.reload();
            });
        }
    };

    //get le workflow actuel
    const getWorkflow = async () => {
        setWorkflow((prevState) => ({
            ...prevState,
            loading: true
        }));
        var wf ;
        var supply ;
        var total ;
        info.contract.methods.getWorkflowStatus().
            call().then((res) => {
                wf = res;
            })
            .catch((err) => {
                setWorkflow(initWorkflowState);
            });
            info.contract.methods.maxTotalSupply().
            call().then((res) => {
                console.log("suply", res);
                supply = res;
            })
            .catch((err) => {
                setWorkflow(initWorkflowState);
            });
            info.contract.methods.totalNFT().
            call().then((res) => {
                total = res;
            })
            .catch((err) => {
                setWorkflow(initWorkflowState);
            });
            info.contract.methods.getPrice().
            call().then((res) => {
                setWorkflow({
                    loading: false,
                    price: res,
                    value : wf,
                    mintNFT: supply,
                    totalNFT: total
                })
            })
            .catch((err) => {
                setWorkflow(initWorkflowState);
            });



    };

    const mintNFT = async () => {
console.log("workflow.price", workflow.price);
console.log("initialInfo.account", info.account);
        info.contract.methods.mainMint(1).send({
            from: info.account,
            value: workflow.price
        })
            .then(res =>
                console.log('Success', res))
            .catch(err => console.log(err));




    };






    console.log(info)

    useEffect(() => {
        init();
        initOnChange();
    }, []);


    return (
        <div>



            <button onClick={() => getWorkflow()}>
                Get Workflow
            </button>

            <div>
                Actual Sale Workflow :
                {(() => {
                    if (workflow.value == "1") {
                        return "CheckOnPresale"
                    }
                    if (workflow.value == "2") {
                        return "Presale"
                    }
                    if (workflow.value == "3") {
                        return "Sale"
                    }
                    if (workflow.value == "4") {
                        return "SoldOut"
                    }
                })()
                }
            </div>

            <div>
                Actual Price Sale :
                {workflow.price}
            </div>

            <div>
                Actual NFT MINT: {workflow.totalNFT} / {workflow.mintNFT}
            </div>


            <button onClick={() => mintNFT()}>
                Mint NFT
            </button>



        </div>
    );

};

export default DropList;
