import React from 'react';
import ReactDOM from 'react-dom';
import DropList from './components/dropList';

ReactDOM.render(
  <React.StrictMode>
    <DropList />
  </React.StrictMode>,
  document.getElementById('root')
);
